# Driver

The common parts for a PMEM-CSI driver deployment. Image versions and
additional parameters for LVM vs. direct mode will be added in
overlays.
