# Kubernetes v1.14 Direct Mode specific changes

This overlay configures the driver to use direct mode.
