# Kubernetes v1.14 LVM Mode specific changes

This overlay configures the driver to use LVM mode.
