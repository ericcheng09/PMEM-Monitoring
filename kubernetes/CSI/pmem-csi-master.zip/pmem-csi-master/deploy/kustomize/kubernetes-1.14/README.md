# Kubernetes v1.14 specific changes

This overlay adds the actual version numbers of the sidecars and the
corresponding RBAC rules such that the base deployment matches
https://github.com/kubernetes-csi/csi-driver-host-path/tree/master/deploy/kubernetes-1.14
