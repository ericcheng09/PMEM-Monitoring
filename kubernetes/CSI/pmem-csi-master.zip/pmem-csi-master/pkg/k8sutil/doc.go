/*
Copyright 2020 Intel Coporation.

SPDX-License-Identifier: Apache-2.0
*/

// The package k8sutil contains some helper code which simplifies
// interaction with a Kubernetes cluster.
package k8sutil
