# Scheduler

This directory contains the implementation of a [scheduler
extender](https://github.com/kubernetes/community/blob/master/contributors/design-proposals/scheduling/scheduler_extender.md).
It is meant to be linked into the PMEM-CSI master controller because
that is where we know about nodes and can get their current capacity.


