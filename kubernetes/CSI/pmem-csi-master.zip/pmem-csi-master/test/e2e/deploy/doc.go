/*
Copyright 2020 Intel Corporation.

SPDX-License-Identifier: Apache-2.0
*/

// Package deploy contains code which provides information about the
// cluster and deploying PMEM-CSI inside it.
package deploy
